/**
 * Employee Payroll Management System
 * Logic for managing employees, processing payroll, and updating UI.
 */

const app = {
    // --- Data ---
    employees: [
        { id: 1, name: 'Rahul Sharma', position: 'Software Engineer', department: 'Engineering', email: 'rahul.s@payflow.com', baseSalary: 850000, bonus: 50000, deductions: 12000, password: 'emp123' },
        { id: 2, name: 'Priya Verma', position: 'Product Manager', department: 'Marketing', email: 'priya.v@payflow.com', baseSalary: 720000, bonus: 40000, deductions: 10000, password: 'emp123' },
        { id: 3, name: 'Amit Patel', position: 'Senior Developer', department: 'Engineering', email: 'amit.p@payflow.com', baseSalary: 900000, bonus: 60000, deductions: 15000, password: 'emp123' },
        { id: 4, name: 'Neha Singh', position: 'HR Executive', department: 'HR', email: 'neha.s@payflow.com', baseSalary: 650000, bonus: 35000, deductions: 8000, password: 'emp123' },
        { id: 5, name: 'Rohit Kumar', position: 'Sales Associate', department: 'Sales', email: 'rohit.k@payflow.com', baseSalary: 580000, bonus: 30000, deductions: 7000, password: 'emp123' },
        { id: 6, name: 'Anjali Mehta', position: 'QA Engineer', department: 'Engineering', email: 'anjali.m@payflow.com', baseSalary: 780000, bonus: 45000, deductions: 11000, password: 'emp123' },
        { id: 7, name: 'Suresh Reddy', position: 'Engineering Manager', department: 'Engineering', email: 'suresh.r@payflow.com', baseSalary: 1000000, bonus: 70000, deductions: 18000, password: 'emp123' },
        { id: 8, name: 'Kavita Iyer', position: 'Content Strategist', department: 'Marketing', email: 'kavita.i@payflow.com', baseSalary: 690000, bonus: 38000, deductions: 9000, password: 'emp123' },
        { id: 9, name: 'Manish Gupta', position: 'Financial Analyst', department: 'Finance', email: 'manish.g@payflow.com', baseSalary: 820000, bonus: 48000, deductions: 12500, password: 'emp123' },
        { id: 10, name: 'Pooja Nair', position: 'Admin Assistant', department: 'HR', email: 'pooja.n@payflow.com', baseSalary: 550000, bonus: 25000, deductions: 6000, password: 'emp123' }
    ],
    payrollRecords: [], // { id, empId, empName, position, month, netPay, status: 'Pending'|'Paid' }

    // Config
    currencyFormatter: new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }),

    // State
    editingId: null,
    currentRole: 'admin', // Default login role selection
    // State
    editingId: null,
    currentRole: 'admin', // Default login role selection
    currentUser: null, // Logged in user data
    charts: { dept: null, payroll: null }, // Chart instances

    // Theme State
    isDarkMode: false,

    // Notification State
    notifications: [],
    // Example: { id: 1, type: 'info', message: 'Welcome back!', time: 'Now', read: false }

    // --- Theme Logic ---
    initTheme() {
        const savedTheme = localStorage.getItem('payflow_theme');
        if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            this.isDarkMode = true;
            document.body.classList.add('dark-mode');
        }
        this.updateThemeIcon();
    },

    toggleTheme() {
        this.isDarkMode = !this.isDarkMode;
        if (this.isDarkMode) {
            document.body.classList.add('dark-mode');
            localStorage.setItem('payflow_theme', 'dark');
        } else {
            document.body.classList.remove('dark-mode');
            localStorage.setItem('payflow_theme', 'light');
        }
        this.updateThemeIcon();
    },

    updateThemeIcon() {
        const btn = document.querySelector('.theme-toggle-btn i');
        if (btn) {
            btn.className = this.isDarkMode ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
        }
    },

    // --- Notification Logic ---
    toggleNotifications() {
        const dropdown = document.getElementById('notification-dropdown');
        const btn = document.querySelector('.notification-btn');
        dropdown.classList.toggle('show');
        btn.classList.toggle('active');

        // Close when clicking outside - handled by global listener usually, or simple toggle for now.
    },

    addNotification(type, message) {
        const newNotif = {
            id: Date.now(),
            type: type, // 'success', 'warning', 'info'
            message: message,
            time: 'Just now', // Ideally real relative time logic
            read: false,
            timestamp: new Date()
        };
        this.notifications.unshift(newNotif);
        this.renderNotifications();
    },

    renderNotifications() {
        const list = document.getElementById('notification-list');
        const badge = document.getElementById('notification-badge');

        // Count Unread
        const unreadCount = this.notifications.filter(n => !n.read).length;
        if (unreadCount > 0) {
            badge.style.display = 'flex';
            badge.textContent = unreadCount > 9 ? '9+' : unreadCount;
        } else {
            badge.style.display = 'none';
        }

        // Render List
        if (this.notifications.length === 0) {
            list.innerHTML = '<div class="no-notifications">No new notifications</div>';
            return;
        }

        list.innerHTML = this.notifications.map(n => {
            let icon = 'fa-circle-info';
            if (n.type === 'success') icon = 'fa-circle-check';
            if (n.type === 'warning') icon = 'fa-triangle-exclamation';

            return `
                <div class="notification-item ${n.read ? '' : 'unread'}">
                    <div class="notif-icon-box type-${n.type}">
                        <i class="fa-solid ${icon}"></i>
                    </div>
                    <div class="notif-content">
                        <div class="notif-message">${n.message}</div>
                        <div class="notif-time">${n.time}</div>
                    </div>
                </div>
            `;
        }).join('');
    },

    markAllRead() {
        this.notifications.forEach(n => n.read = true);
        this.renderNotifications();
    },

    // --- Login Logic ---

    setLoginRole(role) {
        this.currentRole = role;
        // Update UI logic for buttons
        document.querySelectorAll('.role-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(`btn-role-${role}`).classList.add('active');

        // Update placeholder
        const input = document.getElementById('login-email');
        input.placeholder = role === 'admin' ? 'admin@payflow.com' : 'employee@payflow.com';
    },

    togglePassword() {
        const input = document.getElementById('login-password');
        const icon = document.querySelector('.show-pass-icon');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.remove('fa-eye');
            icon.classList.add('fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.remove('fa-eye-slash');
            icon.classList.add('fa-eye');
        }
    },

    handleLogin(event) {
        event.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        const rememberMe = document.getElementById('remember-me').checked;
        const btn = document.getElementById('login-btn');
        const errorMsg = document.getElementById('login-error');

        // Reset Error
        errorMsg.style.display = 'none';

        // Loading State
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Signing In...';
        btn.disabled = true;

        setTimeout(() => {
            let isValid = false;
            let loggedInUser = null;

            if (this.currentRole === 'admin') {
                if (email === 'admin@payflow.com' && password === 'admin123') {
                    isValid = true;
                    loggedInUser = { name: 'Administrator', role: 'admin', email: email };
                }
            } else {
                // Employee Login Logic
                const employee = this.employees.find(e => e.email === email);
                // Use stored password, fallback to 'emp123' if undefined (handling legacy/edge cases)
                const storedPassword = employee?.password || 'emp123';

                if (employee && password === storedPassword) {
                    isValid = true;
                    loggedInUser = { ...employee, role: 'employee' };
                }
            }

            if (isValid) {
                // Success
                this.currentUser = loggedInUser;
                
                // Handle Remember Me functionality
                if (rememberMe) {
                    // Store login session for 30 days
                    const sessionData = {
                        user: loggedInUser,
                        role: this.currentRole,
                        timestamp: Date.now(),
                        expires: Date.now() + (30 * 24 * 60 * 60 * 1000) // 30 days in milliseconds
                    };
                    localStorage.setItem('payflow_remember_session', JSON.stringify(sessionData));
                } else {
                    // Clear any existing remember session
                    localStorage.removeItem('payflow_remember_session');
                }
                
                document.getElementById('login-screen').style.display = 'none';
                document.getElementById('app-dashboard').style.display = 'flex';

                // Update specific UI for user
                const userProfileEl = document.getElementById('user-display-name');
                if (userProfileEl && loggedInUser) {
                    userProfileEl.textContent = loggedInUser.name;
                }

                this.initDashboard(); // Initialize logic only after login
            } else {
                // Error
                errorMsg.style.display = 'flex';
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        }, 1000);
    },

    logout() {
        // Show a more modern confirmation dialog instead of blocking confirm()
        this.showLogoutConfirmation();
    },

    showLogoutConfirmation() {
        // Create modal overlay
        const modalOverlay = document.createElement('div');
        modalOverlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10000;
            backdrop-filter: blur(2px);
        `;

        // Create confirmation dialog
        const confirmDialog = document.createElement('div');
        confirmDialog.style.cssText = `
            background: var(--bg-card);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 90%;
            text-align: center;
            animation: modalSlide 0.3s ease-out;
        `;

        confirmDialog.innerHTML = `
            <div style="margin-bottom: 1.5rem;">
                <i class="fa-solid fa-right-from-bracket" style="font-size: 3rem; color: var(--danger-color); margin-bottom: 1rem; display: block;"></i>
                <h3 style="margin-bottom: 0.5rem; color: var(--text-main);">Confirm Logout</h3>
                <p style="color: var(--text-muted); margin: 0;">Are you sure you want to logout?</p>
            </div>
            <div style="display: flex; gap: 1rem; justify-content: center;">
                <button id="cancel-logout" class="btn btn-secondary">
                    <i class="fa-solid fa-times"></i> Cancel
                </button>
                <button id="confirm-logout" class="btn btn-danger">
                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                </button>
            </div>
        `;

        modalOverlay.appendChild(confirmDialog);
        document.body.appendChild(modalOverlay);

        // Add event listeners
        const cancelBtn = document.getElementById('cancel-logout');
        const confirmBtn = document.getElementById('confirm-logout');

        cancelBtn.addEventListener('click', () => {
            document.body.removeChild(modalOverlay);
        });

        confirmBtn.addEventListener('click', () => {
            this.performLogout();
            document.body.removeChild(modalOverlay);
        });

        // Close on overlay click
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                document.body.removeChild(modalOverlay);
            }
        });

        // Close on Escape key
        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                document.body.removeChild(modalOverlay);
                document.removeEventListener('keydown', handleEscape);
            }
        };
        document.addEventListener('keydown', handleEscape);
    },

    performLogout() {
        // Show loading state briefly to prevent UI freezing
        const logoutBtn = document.querySelector('.logout-btn');
        if (logoutBtn) {
            const originalContent = logoutBtn.innerHTML;
            logoutBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> <span>Logging out...</span>';
            logoutBtn.disabled = true;
        }

        // Use setTimeout to prevent blocking
        setTimeout(() => {
            // Clear Remember Me session
            localStorage.removeItem('payflow_remember_session');
            
            // Reset State
            this.currentUser = null;
            this.currentRole = 'admin';

            // Clear Form
            document.getElementById('login-email').value = '';
            document.getElementById('login-password').value = '';
            document.getElementById('login-error').style.display = 'none';
            document.getElementById('remember-me').checked = false;

            // UI Switch with smooth transition
            const dashboard = document.getElementById('app-dashboard');
            const loginScreen = document.getElementById('login-screen');
            
            // Fade out dashboard
            dashboard.style.transition = 'opacity 0.3s ease-out';
            dashboard.style.opacity = '0';
            
            setTimeout(() => {
                dashboard.style.display = 'none';
                dashboard.style.opacity = '1';
                loginScreen.style.display = 'flex';
                
                // Re-init login role selection to default
                this.setLoginRole('admin');
                
                // Reset logout button
                if (logoutBtn) {
                    logoutBtn.innerHTML = originalContent;
                    logoutBtn.disabled = false;
                }
            }, 300);
        }, 100);
    },

    // --- Persistence ---
    saveData() {
        localStorage.setItem('payflow_employees', JSON.stringify(this.employees));
        localStorage.setItem('payflow_payroll', JSON.stringify(this.payrollRecords));
    },

    loadData() {
        const storedEmployees = localStorage.getItem('payflow_employees');
        const storedPayroll = localStorage.getItem('payflow_payroll');

        if (storedEmployees) {
            this.employees = JSON.parse(storedEmployees);
        } else {
            // Seed initial data if empty
            this.saveData();
        }

        if (storedPayroll) {
            this.payrollRecords = JSON.parse(storedPayroll);
        }
    },

    // --- Remember Me Session Check ---
    checkRememberedSession() {
        const rememberedSession = localStorage.getItem('payflow_remember_session');
        if (rememberedSession) {
            try {
                const sessionData = JSON.parse(rememberedSession);
                
                // Check if session is still valid (not expired)
                if (sessionData.expires && Date.now() < sessionData.expires) {
                    // Session is valid, auto-login
                    this.currentUser = sessionData.user;
                    this.currentRole = sessionData.role;
                    
                    // Update UI
                    document.getElementById('login-screen').style.display = 'none';
                    document.getElementById('app-dashboard').style.display = 'flex';
                    
                    // Update user name in header
                    const userProfileEl = document.getElementById('user-display-name');
                    if (userProfileEl && this.currentUser) {
                        userProfileEl.textContent = this.currentUser.name;
                    }
                    
                    // Set role toggle button
                    this.setLoginRole(this.currentRole);
                    
                    // Initialize dashboard
                    this.initDashboard();
                    
                    // Add notification for auto-login
                    this.addNotification('success', `Welcome back, ${this.currentUser.name}! You've been automatically logged in.`);
                } else {
                    // Session expired, clean it up
                    localStorage.removeItem('payflow_remember_session');
                }
            } catch (error) {
                // Invalid session data, clean it up
                localStorage.removeItem('payflow_remember_session');
            }
        }
    },

    // --- Initialization ---
    init() {
        // Load data first
        this.loadData();

        // Check for remembered session
        this.checkRememberedSession();

        // Initialize Theme
        this.initTheme();

        // Initial Notification (Demo)
        this.addNotification('info', 'Welcome to PayFlow Employee Management System v2.0');

        // Just set up the login role initially if not logged in
        if (!this.currentUser) {
            this.setLoginRole('admin');
        }

        // Set default month to current month
        const today = new Date();
        const monthStr = today.toISOString().slice(0, 7); // YYYY-MM
        document.getElementById('payroll-month').value = monthStr;
        document.getElementById('ps-month').value = monthStr; // Default for Payslip Generator

        // Initial Preview Update
        this.updatePreview();

        // Listener for month change to update dashboard charts
        document.getElementById('payroll-month').addEventListener('change', () => {
            this.renderDashboard();
            this.renderPayroll(); // also re-render the list if needed, though list has its own logic usually
        });
    },

    initDashboard() {
        // Toggle Admin/Employee Restrictions
        const isAdmin = this.currentRole === 'admin';

        const btnAddEmp = document.getElementById('btn-add-employee');
        if (btnAddEmp) btnAddEmp.style.display = isAdmin ? 'inline-block' : 'none';

        const btnProcess = document.getElementById('btn-process-payroll');
        if (btnProcess) btnProcess.style.display = isAdmin ? 'inline-block' : 'none';

        const btnPayslip = document.getElementById('tab-btn-payslip');
        if (btnPayslip) btnPayslip.style.display = isAdmin ? 'inline-block' : 'none';

        // Update user name in header
        const userProfileEl = document.getElementById('user-display-name');
        if (userProfileEl && this.currentUser) {
            userProfileEl.textContent = this.currentUser.name;
        }

        this.initCharts(); // Initialize charts
        this.renderDashboard();
        this.renderEmployees(this.employees);
        this.renderPayroll();
    },

    initCharts() {
        // Register Plugin
        Chart.register(ChartDataLabels);

        const ctxDept = document.getElementById('deptChart').getContext('2d');
        const ctxPayroll = document.getElementById('payrollChart').getContext('2d');

        // Common Datalabels Config
        const datalabelsConfig = {
            color: '#fff',
            font: {
                weight: 'bold',
                size: 12
            },
            formatter: (value, ctx) => {
                let sum = 0;
                let dataArr = ctx.chart.data.datasets[0].data;
                dataArr.map(data => {
                    sum += data;
                });
                let percentage = (value * 100 / sum).toFixed(0) + "%";
                return percentage;
            }
        };

        // Department Chart
        this.charts.dept = new Chart(ctxDept, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: ['#4f46e5', '#22c55e', '#f59e0b', '#ef4444', '#ec4899', '#8b5cf6'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'right' },
                    datalabels: datalabelsConfig
                }
            }
        });

        // Payroll Status Chart
        this.charts.payroll = new Chart(ctxPayroll, {
            type: 'doughnut',
            data: {
                labels: ['Paid', 'Pending'],
                datasets: [{
                    data: [0, 0],
                    backgroundColor: ['#22c55e', '#f59e0b'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' },
                    datalabels: datalabelsConfig
                }
            }
        });
    },

    // --- Render Functions ---
    renderDashboard() {
        // Total Employees
        document.getElementById('total-employees').innerText = this.employees.length;

        // Monthly Payroll (Sum of all latest calculated net pays for active employees roughly or just total historical? 
        // Requirement says "Monthly Payroll". Let's assume it's the potential monthly payout for all current employees.)
        const totalMonthlyLiability = this.employees.reduce((sum, emp) => {
            return sum + (emp.baseSalary / 12) + (emp.bonus / 12) - (emp.deductions / 12);
        }, 0);
        document.getElementById('monthly-payroll').innerText = this.currencyFormatter.format(totalMonthlyLiability);

        // Pending Payments (count from payrollRecords where status === 'Pending')
        const pendingCount = this.payrollRecords.filter(r => r.status === 'Pending').length;
        document.getElementById('pending-payments').innerText = pendingCount;

        // --- Update Charts ---
        if (this.charts.dept && this.charts.payroll) {
            // 1. Dept Data
            const deptCounts = {};
            this.employees.forEach(e => {
                deptCounts[e.department] = (deptCounts[e.department] || 0) + 1;
            });
            this.charts.dept.data.labels = Object.keys(deptCounts);
            this.charts.dept.data.datasets[0].data = Object.values(deptCounts);
            this.charts.dept.update();

            // 2. Payroll Data (Current Selected Month)
            const selectedMonth = document.getElementById('payroll-month').value;
            let paidAmount = 0;
            let pendingAmount = 0;

            // Filter records for the selected month
            const currentMonthRecords = this.payrollRecords.filter(r => r.month === selectedMonth);

            currentMonthRecords.forEach(r => {
                if (r.status === 'Paid') paidAmount += r.netPay;
                else pendingAmount += r.netPay;
            });

            // If empty, show something placeholder or 0
            this.charts.payroll.data.datasets[0].data = [paidAmount, pendingAmount];
            this.charts.payroll.update();
        }
    },

    renderEmployees(data) {
        const tbody = document.getElementById('employee-table-body');
        tbody.innerHTML = '';

        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No employees found.</td></tr>';
            return;
        }

        data.forEach(emp => {
            const netPay = (emp.baseSalary + emp.bonus - emp.deductions) / 12;
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>
                    <div style="font-weight: 500;">${emp.name}</div>
                    <div style="font-size: 0.8rem; color: #64748b;">${emp.email}</div>
                </td>
                <td>${emp.position}</td>
                <td><span class="badge badge-blue">${emp.department}</span></td>
                <td>${this.currencyFormatter.format(emp.baseSalary)}</td>
                <td>${this.currencyFormatter.format(emp.bonus)}</td>
                <td>${this.currencyFormatter.format(emp.deductions)}</td>
                <td style="font-weight: 600; color: var(--success-color);">${this.currencyFormatter.format(netPay)}/mo</td>
                <td>
                    ${this.currentRole === 'admin' ? `
                    <button class="btn btn-sm btn-secondary" onclick="app.editEmployee(${emp.id})"><i class="fa-solid fa-pen"></i></button>
                    <button class="btn btn-sm btn-danger" onclick="app.deleteEmployee(${emp.id})"><i class="fa-solid fa-trash"></i></button>
                    ` : '<span style="color:#aaa;">-</span>'}
                </td>
            `;
            tbody.appendChild(tr);
        });
    },

    renderPayroll() {
        const container = document.getElementById('payroll-history-container');
        container.innerHTML = '';

        let displayRecords = [];

        if (this.currentRole === 'admin') {
            displayRecords = [...this.payrollRecords];
        } else {
            if (this.currentUser) {
                displayRecords = this.payrollRecords.filter(r =>
                    r.empId === this.currentUser.id && r.status === 'Paid'
                );
            }
        }

        if (displayRecords.length === 0) {
            const msg = this.currentRole === 'admin'
                ? 'No payroll records generated yet. Select a month and click Process.'
                : 'No payment history found yet.';
            container.innerHTML = `<div style="text-align:center; padding: 20px; background: white; border-radius: 8px;">${msg}</div>`;
            return;
        }

        // Group by Month
        const groupedByMonth = displayRecords.reduce((acc, record) => {
            if (!acc[record.month]) {
                acc[record.month] = [];
            }
            acc[record.month].push(record);
            return acc;
        }, {});

        // Sort Months Descending
        const months = Object.keys(groupedByMonth).sort().reverse();

        months.forEach(month => {
            // Sort records in this month
            const records = groupedByMonth[month].sort((a, b) => {
                if (this.currentRole === 'admin') {
                    if (a.status === b.status) return a.empName.localeCompare(b.empName);
                    return a.status === 'Pending' ? -1 : 1;
                }
                return 0;
            });

            // Create Section
            const section = document.createElement('div');
            section.style.marginBottom = '2rem';

            const monthHeader = document.createElement('h3');
            monthHeader.style.paddingLeft = '10px';
            monthHeader.style.display = 'flex';
            monthHeader.style.justifyContent = 'space-between';
            monthHeader.style.alignItems = 'center';

            const headerTitle = document.createElement('span');
            headerTitle.textContent = new Date(month + '-01').toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
            monthHeader.appendChild(headerTitle);

            // Add Download Button
            const downloadBtn = document.createElement('button');
            downloadBtn.className = 'btn btn-sm btn-secondary';
            downloadBtn.innerHTML = '<i class="fa-solid fa-file-pdf"></i> Statement';
            downloadBtn.onclick = () => app.downloadStatement(month);
            monthHeader.appendChild(downloadBtn);

            section.appendChild(monthHeader);

            const tableContainer = document.createElement('div');
            tableContainer.className = 'table-container'; // Reuse existing card style

            const table = document.createElement('table');
            table.className = 'data-table';
            table.innerHTML = `
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Position</th>
                        <th>Base Salary</th>
                        <th>Bonus</th>
                        <th>Deductions</th>
                        <th>Net Pay</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody></tbody>
            `;

            const tbody = table.querySelector('tbody');

            records.forEach(record => {
                const statusBadge = record.status === 'Paid' ? 'badge-green' : 'badge-orange';
                const actionBtn = record.status === 'Pending'
                    ? (this.currentRole === 'admin'
                        ? `<button class="btn btn-sm btn-success" onclick="app.markPaid(${record.id})"><i class="fa-solid fa-check"></i> Pay</button>`
                        : '<span style="color: var(--warning-color);">Processing</span>')
                    : '<span style="color: var(--success-color);"><i class="fa-solid fa-circle-check"></i> Paid</span>';

                // Safe access to stored breakdown or fallback to calculation (e.g. 0 or N/A) for legacy data
                // For simplicity, if missing, we default to 0 to avoid breaking.
                const mBase = record.monthlyBase || 0;
                const mBonus = record.monthlyBonus || 0;
                const mDed = record.monthlyDeductions || 0;

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${record.empName}</td>
                    <td>${record.position}</td>
                    <td>${this.currencyFormatter.format(mBase)}</td>
                    <td>${this.currencyFormatter.format(mBonus)}</td>
                    <td style="color: var(--danger-color);">${this.currencyFormatter.format(mDed)}</td>
                    <td style="font-weight: bold;">${this.currencyFormatter.format(record.netPay)}</td>
                    <td><span class="badge ${statusBadge}">${record.status}</span></td>
                    <td>${actionBtn}</td>
                `;
                tbody.appendChild(tr);
            });

            tableContainer.appendChild(table);
            section.appendChild(tableContainer);
            container.appendChild(section);
        });
    },

    // --- Actions ---

    handleSearch(event) {
        const query = event.target.value.toLowerCase();
        const filtered = this.employees.filter(emp =>
            emp.name.toLowerCase().includes(query) ||
            emp.position.toLowerCase().includes(query) ||
            emp.department.toLowerCase().includes(query)
        );
        this.renderEmployees(filtered);
    },

    switchTab(tabName) {
        // Update Buttons
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        event.currentTarget.classList.add('active'); // event is implicitly available in inline handler call context usually, but safer to query if needed. 
        // Actually, 'event' in onclick="app.switchTab()" passes the global event. 
        // To be safe in strict mode, let's fix the button active state logic by index or class.

        // Better logical switch:
        // Hide all views
        document.querySelectorAll('.view-section').forEach(el => el.style.display = 'none');
        // Show target
        document.getElementById(`view-${tabName}`).style.display = 'block';

        // Fix button styling (hacky way using text content or simple loop) (relying on event.target in calling context or just querySelector)
    },

    openModal() {
        this.editingId = null;
        document.getElementById('employee-form').reset();
        document.getElementById('modal-title').innerText = 'Add New Employee';
        document.getElementById('employee-modal').classList.add('active');
    },

    closeModal() {
        document.getElementById('employee-modal').classList.remove('active');
    },

    handleFormSubmit(event) {
        event.preventDefault();

        const name = document.getElementById('emp-name').value;
        const position = document.getElementById('emp-position').value;
        const department = document.getElementById('emp-department').value;
        const email = document.getElementById('emp-email').value;
        const password = document.getElementById('emp-password').value || 'emp123'; // Default to emp123 if empty
        const baseSalary = parseFloat(document.getElementById('emp-salary').value);
        const bonus = parseFloat(document.getElementById('emp-bonus').value) || 0;
        const deductions = parseFloat(document.getElementById('emp-deductions').value) || 0;

        if (this.editingId) {
            // Edit
            const empIndex = this.employees.findIndex(e => e.id === this.editingId);
            if (empIndex > -1) {
                this.employees[empIndex] = { ...this.employees[empIndex], name, position, department, email, baseSalary, bonus, deductions, password };
            }
        } else {
            // Add
            const newId = this.employees.length > 0 ? Math.max(...this.employees.map(e => e.id)) + 1 : 1;
            this.employees.push({ id: newId, name, position, department, email, baseSalary, bonus, deductions, password });
        }


        this.closeModal();
        this.renderEmployees(this.employees);
        this.renderDashboard();
        this.saveData();

        // Notify
        const msg = this.editingId ? 'Employee updated successfully.' : 'New employee added successfully.';
        this.addNotification('success', msg);
    },

    editEmployee(id) {
        const emp = this.employees.find(e => e.id === id);
        if (!emp) return;

        this.editingId = id;
        document.getElementById('emp-name').value = emp.name;
        document.getElementById('emp-position').value = emp.position;
        document.getElementById('emp-department').value = emp.department;
        document.getElementById('emp-email').value = emp.email;
        document.getElementById('emp-password').value = emp.password || 'emp123';
        document.getElementById('emp-salary').value = emp.baseSalary;
        document.getElementById('emp-bonus').value = emp.bonus;
        document.getElementById('emp-deductions').value = emp.deductions;

        document.getElementById('modal-title').innerText = 'Edit Employee';
        document.getElementById('employee-modal').classList.add('active');
    },

    deleteEmployee(id) {
        if (confirm('Are you sure you want to delete this employee?')) {
            this.employees = this.employees.filter(e => e.id !== id);
            this.renderEmployees(this.employees);
            this.renderDashboard();
            this.saveData();
        }
    },

    processPayroll() {
        const month = document.getElementById('payroll-month').value;
        if (!month) {
            alert("Please select a month first.");
            return;
        }

        // Check if already processed for this month (optional, but good UX)
        // For simplicity, we'll append. Or maybe filter out duplicates? 
        // Let's just create new records for active employees for that month.

        let count = 0;
        this.employees.forEach(emp => {
            // Check if already exists for this employee and month
            const exists = this.payrollRecords.some(r => r.empId === emp.id && r.month === month);
            if (!exists) {
                const monthlyBase = emp.baseSalary / 12;
                const monthlyBonus = emp.bonus / 12;
                const monthlyDeductions = emp.deductions / 12;
                const netPay = monthlyBase + monthlyBonus - monthlyDeductions;

                this.payrollRecords.push({
                    id: Date.now() + Math.random(),
                    empId: emp.id,
                    empName: emp.name,
                    position: emp.position,
                    month: month,
                    monthlyBase: monthlyBase,
                    monthlyBonus: monthlyBonus,
                    monthlyDeductions: monthlyDeductions,
                    netPay: netPay,
                    status: 'Pending'
                });
                count++;
            }
        });

        if (count > 0) {
            // alert(`Payroll processed for ${count} employees.`); // Replaced with notification
            this.addNotification('success', `Payroll processed successfully for ${count} employees.`);
            this.renderPayroll();
            this.renderDashboard();
            this.saveData();
        } else {
            // alert('Payroll already processed for all employees for this month.');
            this.addNotification('warning', 'Payroll already processed for this month.');
        }
    },

    markPaid(recordId) {
        const record = this.payrollRecords.find(r => r.id === recordId);
        if (record) {
            record.status = 'Paid';
            this.renderPayroll();
            this.renderDashboard();
            this.saveData();
            this.addNotification('success', `Payment marked as Paid for ${record.empName}.`);
        }
    },

    // --- Payslip Generator ---

    updatePreview() {
        // Gather Values
        const name = document.getElementById('ps-name').value || 'John Doe';
        const position = document.getElementById('ps-position').value || 'Software Engineer';
        const month = document.getElementById('ps-month').value;

        // Date Parsing
        let monthText = 'October 2023';
        let dateText = '2023-10-31';
        if (month) {
            const d = new Date(month + '-01');
            monthText = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
            // Last day of month
            const lastDay = new Date(d.getFullYear(), d.getMonth() + 1, 0);
            dateText = lastDay.toISOString().split('T')[0];
        }

        const basic = parseFloat(document.getElementById('ps-basic').value) || 0;
        const hra = parseFloat(document.getElementById('ps-hra').value) || 0;
        const conveyance = parseFloat(document.getElementById('ps-conveyance').value) || 0;
        const bonus = parseFloat(document.getElementById('ps-bonus').value) || 0;

        const pf = parseFloat(document.getElementById('ps-pf').value) || 0;
        const tax = parseFloat(document.getElementById('ps-tax').value) || 0;

        // Calculations
        const totalEarnings = basic + hra + conveyance + bonus;
        const totalDeductions = pf + tax;
        const netPay = totalEarnings - totalDeductions;

        // Update DOM
        document.getElementById('prev-name').textContent = name;
        document.getElementById('prev-position').textContent = position;
        document.getElementById('prev-month').textContent = monthText;
        document.getElementById('prev-date').textContent = dateText;

        document.getElementById('prev-basic').textContent = this.currencyFormatter.format(basic).replace('₹', ''); // Removing symbol for clean table alignment usually prefered, but defined '₹' in header relative to format. Let's keep consistent.
        // Actually table header says Amount (₹), so maybe just numbers? Let's use currency formatter but maybe without symbol if header has it.
        // But formatter is easiest. Let's just use formatter.
        document.getElementById('prev-basic').textContent = this.currencyFormatter.format(basic);
        document.getElementById('prev-hra').textContent = this.currencyFormatter.format(hra);
        document.getElementById('prev-conveyance').textContent = this.currencyFormatter.format(conveyance);
        document.getElementById('prev-bonus').textContent = this.currencyFormatter.format(bonus);

        document.getElementById('prev-pf').textContent = this.currencyFormatter.format(pf);
        document.getElementById('prev-tax').textContent = this.currencyFormatter.format(tax);

        document.getElementById('prev-total-earn').textContent = this.currencyFormatter.format(totalEarnings);
        document.getElementById('prev-total-ded').textContent = this.currencyFormatter.format(totalDeductions);

        document.getElementById('prev-net-pay').textContent = this.currencyFormatter.format(netPay);
    },

    generatePDF() {
        const element = document.getElementById('payslip-preview-content');
        const name = document.getElementById('ps-name').value || 'Employee';
        const month = document.getElementById('ps-month').value || 'Current';

        // Create a clone of the payslip content for better PDF generation
        const payslipClone = element.cloneNode(true);
        
        // Enhanced PDF options with better visibility settings
        const opt = {
            margin: [0.5, 0.5],
            filename: `Payslip_${name}_${month}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { 
                scale: 2,
                useCORS: true,
                logging: false,
                letterRendering: true,
                allowTaint: true,
                backgroundColor: '#ffffff'
            },
            jsPDF: { 
                unit: 'in', 
                format: 'letter', 
                orientation: 'portrait',
                compress: true
            }
        };

        // Create a dedicated container for payslip PDF generation
        const pdfContainer = document.createElement('div');
        pdfContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 999999;
            background: #ffffff;
            overflow: auto;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        `;

        // Style the payslip clone for optimal PDF visibility
        payslipClone.style.cssText = `
            background: #ffffff !important;
            color: #1e293b !important;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
            line-height: 1.4 !important;
            visibility: visible !important;
            opacity: 1 !important;
            width: 100%;
            max-width: 500px;
            padding: 2rem;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            box-sizing: border-box;
        `;

        // Add comprehensive style reset for payslip
        const styleReset = document.createElement('style');
        styleReset.textContent = `
            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                color-adjust: exact !important;
            }
            
            .payslip-paper {
                background: #ffffff !important;
                color: #1e293b !important;
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
                line-height: 1.4 !important;
                visibility: visible !important;
                opacity: 1 !important;
            }
            
            .payslip-paper * {
                visibility: visible !important;
                opacity: 1 !important;
                color: inherit !important;
            }
            
            .payslip-paper .ps-header h1 {
                color: #4f46e5 !important;
                font-weight: 700 !important;
            }
            
            .payslip-paper .ps-header h2 {
                color: #4f46e5 !important;
                font-weight: 600 !important;
            }
            
            .payslip-paper .ps-info-grid strong {
                color: #1e293b !important;
                font-weight: 600 !important;
            }
            
            .payslip-paper .ps-info-grid p {
                color: #475569 !important;
            }
            
            .payslip-paper .ps-table {
                border-collapse: collapse !important;
                width: 100% !important;
            }
            
            .payslip-paper .ps-table th {
                background: #f8fafc !important;
                color: #475569 !important;
                font-weight: 600 !important;
                border: 1px solid #e2e8f0 !important;
            }
            
            .payslip-paper .ps-table td {
                color: #334155 !important;
                border: 1px solid #e2e8f0 !important;
                background: #ffffff !important;
            }
            
            .payslip-paper .ps-total-row td {
                background: #f8fafc !important;
                color: #1e293b !important;
                font-weight: 700 !important;
            }
            
            .payslip-paper .ps-net-pay {
                background: #e0e7ff !important;
                color: #3730a3 !important;
                font-weight: 700 !important;
            }
            
            .payslip-paper p {
                color: #334155 !important;
            }
        `;

        pdfContainer.appendChild(payslipClone);
        pdfContainer.appendChild(styleReset);
        document.body.appendChild(pdfContainer);

        // Scroll to top for proper rendering
        window.scrollTo(0, 0);

        // Generate PDF with improved timing
        setTimeout(() => {
            html2pdf()
                .set(opt)
                .from(payslipClone)
                .save()
                .then(() => {
                    // Cleanup
                    if (document.body.contains(pdfContainer)) {
                        document.body.removeChild(pdfContainer);
                    }
                    this.addNotification('success', `Payslip for ${name} downloaded successfully.`);
                })
                .catch(err => {
                    console.error('Payslip PDF Generation Error:', err);
                    // Cleanup on error
                    if (document.body.contains(pdfContainer)) {
                        document.body.removeChild(pdfContainer);
                    }
                    this.addNotification('warning', 'Failed to generate payslip PDF. Please try again.');
                });
        }, 1000); // 1 second delay for proper rendering
    },

    downloadStatement(month) {
        // Filter Records
        const records = this.payrollRecords.filter(r => r.month === month);
        if (records.length === 0) {
            this.addNotification('warning', 'No records found for this month to generate statement.');
            return;
        }

        const monthName = new Date(month + '-01').toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

        // Calculate Totals
        const totalPayout = records.reduce((sum, r) => sum + r.netPay, 0);

        // Create Template with improved structure
        const template = document.createElement('div');
        template.className = 'pdf-report-container';
        
        // Enhanced HTML structure for better visibility
        template.innerHTML = `
            <div class="pdf-header">
                <h1>PayFlow Technologies</h1>
                <h2>Monthly Payroll Statement</h2>
                <p>Period: <strong>${monthName}</strong></p>
            </div>
            
            <div class="pdf-summary">
                <div class="summary-item">
                    <span>Total Employees</span>
                    <strong>${records.length}</strong>
                </div>
                <div class="summary-item">
                    <span>Total Payout</span>
                    <strong>${this.currencyFormatter.format(totalPayout)}</strong>
                </div>
                <div class="summary-item">
                    <span>Generated On</span>
                    <strong>${new Date().toLocaleDateString()}</strong>
                </div>
            </div>

            <table class="pdf-table">
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Position</th>
                        <th>Base Salary</th>
                        <th>Net Pay</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${records.map(r => `
                        <tr>
                            <td><strong>${r.empName}</strong></td>
                            <td>${r.position}</td>
                            <td>${this.currencyFormatter.format(r.monthlyBase || 0)}</td>
                            <td style="font-weight:bold; color: #059669;">${this.currencyFormatter.format(r.netPay)}</td>
                            <td><span style="padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.8rem; font-weight: 600; background: ${r.status === 'Paid' ? '#dcfce7' : '#fef3c7'}; color: ${r.status === 'Paid' ? '#166534' : '#92400e'};">${r.status}</span></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            
            <div class="pdf-footer">
                <p><strong>Authorized Signature:</strong> _______________________</p>
                <p style="margin-top: 1rem; font-style: italic;">This is a system generated report.</p>
                <p style="margin-top: 0.5rem; font-size: 0.7rem; color: #94a3b3;">Generated on ${new Date().toLocaleString()}</p>
            </div>
        `;

        // Enhanced PDF generation with better visibility handling
        const opt = {
            margin: [0.5, 0.5],
            filename: `Payroll_Statement_${month}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { 
                scale: 2,
                useCORS: true,
                logging: false,
                letterRendering: true,
                allowTaint: true
            },
            jsPDF: { 
                unit: 'in', 
                format: 'letter', 
                orientation: 'portrait',
                compress: true
            }
        };

        // Improved visibility strategy - use a dedicated container
        const pdfContainer = document.createElement('div');
        pdfContainer.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 999999;
            background: #ffffff;
            overflow: auto;
            padding: 20px;
            box-sizing: border-box;
        `;

        // Add the template to the container
        pdfContainer.appendChild(template);
        document.body.appendChild(pdfContainer);

        // Enhanced style reset for maximum visibility
        const styleReset = document.createElement('style');
        styleReset.textContent = `
            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                color-adjust: exact !important;
            }
            
            .pdf-report-container {
                background: #ffffff !important;
                color: #1e293b !important;
                font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
                line-height: 1.4 !important;
                visibility: visible !important;
                opacity: 1 !important;
            }
            
            .pdf-report-container * {
                visibility: visible !important;
                opacity: 1 !important;
                color: inherit !important;
            }
            
            .pdf-report-container h1, .pdf-report-container h2, .pdf-report-container h3 {
                color: #1e293b !important;
                font-weight: 700 !important;
            }
            
            .pdf-report-container .pdf-header h1 {
                color: #4f46e5 !important;
            }
            
            .pdf-report-container table {
                border-collapse: collapse !important;
                width: 100% !important;
            }
            
            .pdf-report-container th {
                background: #f1f5f9 !important;
                color: #334155 !important;
                font-weight: 700 !important;
                border: 1px solid #cbd5e1 !important;
            }
            
            .pdf-report-container td {
                color: #1e293b !important;
                border: 1px solid #cbd5e1 !important;
                background: #ffffff !important;
            }
            
            .pdf-report-container .pdf-summary {
                background: #f8fafc !important;
                border: 1px solid #e2e8f0 !important;
            }
            
            .pdf-report-container .pdf-footer {
                color: #64748b !important;
                border-top: 1px solid #e2e8f0 !important;
            }
        `;
        pdfContainer.appendChild(styleReset);

        // Scroll to top and ensure proper rendering
        window.scrollTo(0, 0);

        // Generate PDF with improved timing
        setTimeout(() => {
            html2pdf()
                .set(opt)
                .from(template)
                .save()
                .then(() => {
                    // Cleanup
                    if (document.body.contains(pdfContainer)) {
                        document.body.removeChild(pdfContainer);
                    }
                    this.addNotification('success', `Statement for ${monthName} downloaded successfully.`);
                })
                .catch(err => {
                    console.error('PDF Generation Error:', err);
                    // Cleanup on error
                    if (document.body.contains(pdfContainer)) {
                        document.body.removeChild(pdfContainer);
                    }
                    this.addNotification('warning', 'Failed to generate PDF statement. Please try again.');
                });
        }, 1500); // Increased delay for better rendering
    }
};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    app.init();
});
