# PayFlow Employee Management System - Code Analysis

## Overview
**PayFlow Technologies** is a browser-based **Employee Payroll Management System** designed as a Single Page Application (SPA). It operates entirely on the client side, using **Vanilla JavaScript**, **HTML5**, and **CSS3**, with **Local Storage** for data persistence.

## Key Features

### 1. Authentication
*   **Dual Role System:** 
    *   **Admin:** Full access to manage employees and payroll. (Default: `admin@payflow.com` / `admin123`)
    *   **Employee:** Read-only access to personal records. (Default password: `emp123`)
*   **Secure Implementation:** Basic client-side validation handles login mapping and session state.

### 2. Dashboard
*   **Real-time Metrics:** Displays total employees, monthly payroll liability, and pending payments.
*   **Data Visualization:** Uses **Chart.js** to render:
    *   *Department Distribution* (Doughnut Chart)
    *   *Payroll Status* (Paid vs Pending)

### 3. Core Modules
*   **Employee Management:** Admin-only interface to Add, Edit, Delete, and Search employee records.
*   **Payroll Processing:** Batch processing capability to generate monthly payroll records for all employees based on defined salary structures.
*   **Payslip Generator:** A dynamic tool that creates monthly payslips with a live preview and **PDF Export** functionality (via `html2pdf.js`).

## Technical Architecture

*   **Frontend:** Pure HTML/CSS/JS. No build step or framework (React/Vue) required.
*   **Data Storage:** `localStorage` is used to mimic a database, storing:
    *   `payflow_employees`: Array of employee objects.
    *   `payflow_payroll`: Array of payroll transaction records.
*   **Styling:** Custom CSS using CSS variables for theming (`--primary-color`), Flexbox/Grid for layout, and media queries for responsiveness.

## Project Files
*   **`index.html`**: Contains the DOM structure for all views (Login, Dashboard, Modals).
*   **`script.js`**: Centralized logic controller (`app` object) handling events, routing (tab switching), and data logic.
*   **`style.css`**: Comprehensive stylesheet for the application's visual design.
